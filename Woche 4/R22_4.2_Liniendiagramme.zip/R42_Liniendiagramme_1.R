codeoceanR::rt_score()
codeoceanR::rt_plot1()

# Nochmals: Grafiken automatisiert testen ist schwer.
# Code prüfen ist wahrlich nicht perfekt, aber ein besseres System kenne ich nicht.
# Leider geht hierbei viel Freiheit verloren.
# Schreibe außerhalb der Code Abschnitte gerne Alternativen für dich selbst zum Festhalten!

 
# t1_start
 
plot(x=airquality$date, y=airquality$temp,xlab="Tag im Jahr 1973", ylab="Temperatur in °F"
     ,main="Temperatur in New York, 1973",  type="l", lwd=2, lty=3,xlim=c(1,150),
     ylim=c(min(airquality$temp, na.rm=TRUE))
     )

# t1_ende

# A1 ----
# Zeichne die Temperatur aus 'airquality' (New York, 1973) als Liniendiagramm.
# Hinweis: Bei einem einzelnen Vektor bedeutet der Argumentname "x" die y-Koordinaten.
# Siehe 4.1 Zusatzfolie "Vektor als Input".

# A2 ----
# Verdopple die Linienbreite. (Ändere den Code oben)
# Mache sie gepunktet.
# Verwende die Farbe "chocolate" für die Linie.

# A3 ----
# Aus dem Bonusmaterial zu Lektion 4.1 Punktdiagramme:
# Unterdrücke das Beschriften der vertikalen Achse mit Zahlen.


# Wenn du fertig bist, übermittle bitte deinen Punktestand an openHPI mit:
# codeoceanR::rt_submit()
codeoceanR::rt_plot2() 