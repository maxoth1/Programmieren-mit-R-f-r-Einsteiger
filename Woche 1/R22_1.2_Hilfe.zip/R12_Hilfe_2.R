codeoceanR::rt_score()

# A6 ----
# Wieviele Seiten hat das RefCard von Tom Short?
refCardAnzahlSeiten <- 4
help("refCardAnzahlSeiten")
??"refCardAnzahlSeiten"
help(refCardAnzahlSeiten)
example(refCardAnzahlSeiten)
# A7 ----
# Im Rstudio base R cheat sheet steht die Syntax, um die Doku von Funktionen aufzurufen.
# (Gleich im Abschnitt Getting Help)
# Welche Funktion wird dort als erstes Beispiel verwendet?
cheatSheetFunktion <- "mean"
??cheatSheetFunktion
help(help)
help
# Pro Tipp: drucke eine RefCard deiner Wahl aus und markiere 
# nach und nach farblich, was du alles gelernt und verstanden hast.


# A8 ----
# Was ist der Link zu aktuellen R Fragen auf Stackoverflow? (der https Teil ist optional)
soLinkR <- "https://stackoverflow.com/questions/tagged/r"
help(soLinkR)

# A9 ----
# Welchen Beitrag im Kursforum findest du bisher am hilfreichsten?
forumLink <- "https://open.hpi.de/courses/programmieren-r2022/question/6524da5a-90f9-40a4-8d3a-9b103bd4313c"

# Wenn du fertig bist, übermittle bitte deinen Punktestand an openHPI mit:
# codeoceanR::rt_submit()