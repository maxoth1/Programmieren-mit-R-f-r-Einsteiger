codeoceanR::rt_score()

zahlenFolge <- seq(1, 20, len=15)

# A7 ----
# Erhalte das 12. Element von 'zahlenFolge'.
element12 <- c(15.928571)

# A8 ----
# Erhalte das 4. und 2. Element von 'zahlenFolge'.
element4_2 <- c(5.071429, 2.357143)
zahlenFolge[4:2]

# A9 ----
# Erhalte alle Elemente von 'zahlenFolge', außer Elemente 8 bis 13.
# Pro Tipp: negative Indizierung nutzen
elementOhne <-  c(1.000000,2.357143,3.714286,5.071429,6.428571,7.785714,9.142857,18.642857,20.000000)
zahlenFolge[-(8:13)]

# A10 ----
# Ändere das 8. Element von 'zahlenFolge' zu 99.

zahlenFolge[8] <- 99
# Mache weiter in "R13_Vektoren_3.R"